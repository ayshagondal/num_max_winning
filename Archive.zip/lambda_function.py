
# Install required libraries

import requests
from bs4 import BeautifulSoup

def scrape_website(url):
  """Scrapes data from a website and returns it in a list of dictionaries."""

  response = requests.get(url)
  response.raise_for_status()  # Raise an exception for bad status codes

  soup = BeautifulSoup(response.content, 'html.parser')

  # Example: Extract all <h2> headings and their text content
  data = []
  for heading in soup.find_all('h2'):
    data.append({'heading': heading.text.strip()})

  return data

def lambda_handler(event, context):
  """AWS Lambda handler function."""
 
  event = {'url': 'http://www.lottolore.com/l6490624.html'}
  url = event.get('url')  # Get the URL to scrape from the event object
  if not url:
    return {'statusCode': 400, 'body': 'Missing URL'}

  try:
    data = scrape_website(url)
    # TODO: Insert data into a database or other storage

    return {'statusCode': 200, 'body': 'Data scraped successfully'}
  except requests.exceptions.RequestException as e:
    return {'statusCode': 500, 'body': f'Error scraping website: {e}'}

